Funciones que para el análisis y la gestion de los datos, estas 
implementaciones pueden ser usadas tanto para vectores como para 
dataframes completos.